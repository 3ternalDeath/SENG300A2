import java.util.ArrayList;
import java.util.List;

import org.eclipse.jdt.core.dom.*;

public class CountingVisitor extends org.eclipse.jdt.core.dom.ASTVisitor {

	private static CountingVisitor thatOneInstance = new CountingVisitor();
	
    private List<int[]> counts;		//index 0, declarations; index 1, references
    private List<String> types;
    
    public static CountingVisitor getTheTing() {		// return thatOneInstance
    	return thatOneInstance;
    }
    
    public static void reset() {						// reset thatOneInstance (clean counts, types) 
    	thatOneInstance = new CountingVisitor();
    }

    private CountingVisitor() {
        counts = new ArrayList<int[]>();
        types = new ArrayList<String>();
    }

    public List<int[]> getCounts() {		// return counts list 
        return counts;
    }

    public List<String> getJavaType() {		// return types list
        return types;
    }
    
    private boolean checkDeclarations(AbstractTypeDeclaration node) {
        String name = node.resolveBinding().getQualifiedName();
        if(types.contains(name)) {				
            int i = types.indexOf(name);	//if this type is already contain in the list, increment the count of this type
            counts.get(i)[0]++;
            
        }
        else {
            types.add(name);				//if this is a new type, store it in both type and count
            counts.add(new int[] {1, 0});
        }
        return true;
    }
    
    private boolean checkRef(String name) {
    	if(types.contains(name)){			//if this type is already contain in the list, increment the count of this type
            int i = types.indexOf(name);
            counts.get(i)[1]++;
        }
        else {								//if this is a new type, store it in both type and count
        	types.add(name);
        	counts.add(new int[] {0, 1});
        }
    	
    	return true;
    }

    /////////////////////// declarations count ///////////////////////////
    
    public boolean visit(TypeDeclaration node) {
    	return checkDeclarations(node);
    }

    @Override
    public boolean visit(AnnotationTypeDeclaration node) {
        return checkDeclarations(node);
    }

    @Override
    public boolean visit(EnumDeclaration node) {
        return checkDeclarations(node);
    }

    /////////////////////// references count ///////////////////////////

    @Override
    public boolean visit(SimpleName node) {
        String name = node.getFullyQualifiedName();
        return checkRef(name);
    }

    @Override
    public boolean visit(PrimitiveType node) {
        String name = node.getPrimitiveTypeCode().toString();
        return checkRef(name);
    }
}
